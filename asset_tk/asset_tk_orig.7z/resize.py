from PIL import Image
from pathlib import Path
import shutil

dir = 'asset_tk'
f = 'closed.png'

p = dir / Path(f)
# p.rename(Path(p.parent, f"{p.stem}_1_{p.suffix}"))

shutil.copy(p, f'{p.stem}_orig{p.suffix}')

# image = Image.open('myimage.jpg')
# new_image = image.resize((500, 500))
# new_image.save('myimage_500.jpg')